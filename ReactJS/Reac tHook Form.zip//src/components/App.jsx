import React, { useState } from "react";

function App() {
  const [name, setName] = useState("");
  const [isMouseOver, setColor] = useState(false);
  const [inputName, setInputName] = useState("");

  function handleInputName(event) {
    setInputName(event.target.value);
  }

  function handleMouseOver() {
    setColor(true);
  }

  function handleMouseOut() {
    setColor(false);
  }

  function handleChange() {
    setName(inputName);
  }

  return (
    <div className="container">
      <h1>Hello {name}</h1>
      <input
        onChange={handleInputName}
        s
        type="text"
        placeholder="What's your name?"
        value={inputName}
      />
      <button
        style={{ backgroundColor: isMouseOver ? "black" : "white" }}
        onMouseOver={handleMouseOver}
        onMouseOut={handleMouseOut}
        onClick={handleChange}
      >
        Submit
      </button>
    </div>
  );
}

export default App;
