const url = 'https://www.course-api.com/react-tours-project';

const App = () => {
  return <h2>Tours Starter</h2>;
};
export default App;
