const App = () => {
  return <h2>Strapi Starter</h2>;
};
export default App;
