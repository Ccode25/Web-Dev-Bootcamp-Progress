const App = () => {
  return <h2>Grocery Bud - Starter</h2>;
};

export default App;
