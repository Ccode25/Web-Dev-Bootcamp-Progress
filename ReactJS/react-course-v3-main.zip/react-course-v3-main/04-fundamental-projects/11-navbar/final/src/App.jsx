import Navbar from './Navbar';
const App = () => {
  return (
    <main>
      <Navbar />
    </main>
  );
};
export default App;
