import Title from './components/Title';
function App() {
  return (
    <main>
      <Title />
    </main>
  );
}

export default App;
