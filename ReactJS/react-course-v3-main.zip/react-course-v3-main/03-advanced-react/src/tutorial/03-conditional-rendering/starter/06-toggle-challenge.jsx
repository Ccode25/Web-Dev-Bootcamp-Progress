const ToggleChallenge = () => {
  return <h2>toggle challenge</h2>;
};

export default ToggleChallenge;
