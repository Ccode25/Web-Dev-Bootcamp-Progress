import FirstComponent from './FirstComponent';
import SecondComponent from './SecondComponent';

const Example = () => {
  return (
    <div>
      <FirstComponent />
      <SecondComponent />
    </div>
  );
};
export default Example;
